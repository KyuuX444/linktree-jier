# PROMPT — BENTO HUB LINK-IN-BIO WEBSITE

Buat website personal link-in-bio seperti Linktree dengan nama konsep **Bento Hub**. Website harus memiliki UI/UX premium, responsif, ringan, dan benar-benar dinamis. Jangan membuat hasil berupa HTML statis saja.

## Tujuan
Halaman personal yang menampilkan:
- Foto profil (PP)
- Nama
- Deskripsi/bio
- Kumpulan link dalam Bento Grid
- Bubble Button untuk link sosial dan tautan penting
- Repositori GitHub publik milik `KyuuX444`

Sumber GitHub:
`https://github.com/KyuuX444`

## Desain
- Bento Hub dengan Bento Grid yang fleksibel; gunakan variasi ukuran card yang disengaja.
- Dark mode sebagai tema awal, warna aksen elegan, tipografi modern, radius konsisten, dan spacing rapi.
- Bubble Button berbentuk pill atau lingkaran dengan ikon, label bila diperlukan, tooltip, hover/tap feedback, dan animasi ringan.
- Tampilan mobile-first, tablet, dan desktop harus sama-sama rapi.
- Hindari desain generik/AI slop, glow berlebihan, animasi berat, dan elemen dekoratif yang tidak berguna.
- Hormati `prefers-reduced-motion` dan pastikan kontras serta navigasi keyboard memadai.

## Profil
Buat bagian profil dengan PP, nama, deskripsi, dan bubble button untuk link sosial. Nilai profil dan daftar link custom harus bisa diubah dari satu file konfigurasi tanpa mengedit komponen UI.

## Integrasi GitHub Dinamis
Ambil repositori publik milik `KyuuX444` melalui GitHub REST API:
`https://api.github.com/users/KyuuX444/repos?sort=updated&per_page=100`

- Data repositori harus berasal dari API, bukan daftar repositori hardcode.
- Tampilkan nama repositori, deskripsi jika tersedia, bahasa pemrograman, jumlah stars, serta tautan ke repositori aslinya.
- Gunakan `html_url` dari respons API sebagai tujuan link.
- Sediakan loading skeleton, error state, empty state, dan tombol coba lagi.
- Tangani rate limit, deskripsi kosong, serta data yang tidak tersedia tanpa membuat informasi palsu.
- Cache data secara wajar dan hindari request berulang yang tidak diperlukan.
- Tautan manual tambahan seperti website, WhatsApp, Telegram, Instagram, atau Discord boleh disimpan dalam file konfigurasi.
- Jangan menampilkan repositori privat atau mengarang data.
- Jangan meminta token GitHub untuk mengambil repositori publik. Jika token opsional kelak diperlukan, jangan pernah mengekspos secret di frontend.

## Bubble Button
- Gunakan ikon SVG atau Lucide Icons.
- Setiap tombol harus mempunyai tujuan yang benar dan dapat diklik.
- Berikan hover, focus-visible, active state, dan tooltip untuk tombol ikon tanpa label.
- Ukuran target sentuh nyaman di perangkat mobile.
- Tautan eksternal yang dibuka di tab baru harus menggunakan `rel="noopener noreferrer"`.
- Jangan gunakan tombol dekoratif yang tidak melakukan apa pun.

## Persyaratan Teknologi — WAJIB
- Gunakan stack aplikasi modern, misalnya Next.js/React + TypeScript + Tailwind CSS.
- Website harus merupakan aplikasi yang bisa dijalankan dan dikembangkan, bukan sekadar file HTML/CSS statis.
- Gunakan komponen reusable dan pisahkan profile, bubble buttons, bento cards, GitHub data fetching, serta footer.
- Semua data GitHub harus diambil secara dinamis dari API.
- Sertakan `package.json`, lockfile yang sesuai, konfigurasi framework, konfigurasi styling, source code, dan README berisi cara instalasi, development, build, dan deploy.
- Pastikan kompatibel dengan deployment Vercel.
- Jangan menambahkan backend, database, autentikasi, atau fitur yang tidak dibutuhkan.
- Jangan mengirim hanya screenshot, mockup, satu file HTML, atau potongan kode.
- Jangan menulis placeholder untuk fitur utama. Implementasikan seluruh alur yang diminta.

## Struktur dan Kualitas
Susun halaman dengan urutan:
1. Header minimalis.
2. Profile card: PP, nama, dan deskripsi.
3. Bubble buttons untuk tautan sosial/prioritas.
4. Bento Grid repositori GitHub.
5. Custom links dan footer minimalis.

Pastikan SEO metadata, page title, favicon yang layak, Open Graph metadata, loading/error/empty states, responsivitas, dan performa sudah ditangani. Jangan membuat statistik atau tautan palsu.

## Output Akhir — WAJIB ZIP
- Buat seluruh source code yang lengkap dan bisa dijalankan.
- Sertakan semua file konfigurasi dan README.
- Uji instalasi dependency, build, dan jalankan pemeriksaan yang tersedia sebelum menyerahkan hasil.
- Kompres folder proyek menjadi `bento-hub.zip`.
- Berikan file ZIP yang dapat diunduh, bukan sekadar menampilkan prompt atau source code di chat.
- Laporkan secara singkat teknologi yang digunakan, cara menjalankan proyek, dan hasil pemeriksaan build.
